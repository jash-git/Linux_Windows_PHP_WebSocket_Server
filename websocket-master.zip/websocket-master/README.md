# websocket
一个 PHP 的 websocket 的聊天室

具体设计可查看：[网页实时聊天之PHP实现websocket](http://www.cnblogs.com/zhenbianshu/p/6111257.html)
